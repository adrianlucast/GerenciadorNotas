package com.example.gerenciadornotas;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edNome;
    private EditText edEmail;
    private EditText edIdade;
    private EditText edDisciplina;
    private EditText edNota1;
    private EditText edNota2;

    private TextView tvErro;
    private TextView tvResultado;

    private Button btEnviar;
    private Button btLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.edNome);
        edEmail = findViewById(R.id.edEmail);
        edIdade = findViewById(R.id.edIdade);
        edDisciplina = findViewById(R.id.edDisciplina);
        edNota1 = findViewById(R.id.edNota1);
        edNota2 = findViewById(R.id.edNota2);

        tvErro = findViewById(R.id.tvErro);
        tvResultado = findViewById(R.id.tvResultado);

        btEnviar = findViewById(R.id.btEnviar);
        btLimpar = findViewById(R.id.btLimpar);

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarEExibir();
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparFormulario();
            }
        });
    }

    private void validarEExibir() {
        String nome = edNome.getText().toString().trim();
        String email = edEmail.getText().toString().trim();
        String idadeStr = edIdade.getText().toString().trim();
        String disciplina = edDisciplina.getText().toString().trim();
        String nota1Str = edNota1.getText().toString().trim();
        String nota2Str = edNota2.getText().toString().trim();

        tvErro.setVisibility(View.GONE);
        tvResultado.setVisibility(View.GONE);

        if (TextUtils.isEmpty(nome)) {
            exibirErro("O campo de nome está vazio");
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            exibirErro("O email é inválido");
            return;
        }

        int idade;
        try {
            idade = Integer.parseInt(idadeStr);
            if (idade <= 0) {
                exibirErro("A idade deve ser um número positivo");
                return;
            }
        } catch (NumberFormatException e) {
            exibirErro("A idade deve ser um número válido");
            return;
        }

        float nota1, nota2;
        try {
            nota1 = Float.parseFloat(nota1Str);
            nota2 = Float.parseFloat(nota2Str);
            if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
                exibirErro("As notas devem estar entre 0 e 10");
                return;
            }
        } catch (NumberFormatException e) {
            exibirErro("As notas devem ser números válidos");
            return;
        }

        float media = (nota1 + nota2) / 2;
        String status = media >= 6 ? "Aprovado" : "Reprovado";

        String resultado = "Nome: " + nome + "\n" +
                "Email: " + email + "\n" +
                "Idade: " + idade + "\n" +
                "Disciplina: " + disciplina + "\n" +
                "Notas 1º e 2º Bimestres: " + nota1 + ", " + nota2 + "\n" +
                "Média: " + media + "\n" +
                "Status: " + status;

        tvResultado.setText(resultado);
        tvResultado.setVisibility(View.VISIBLE);
    }

    private void exibirErro(String mensagem) {
        tvErro.setText(mensagem);
        tvErro.setVisibility(View.VISIBLE);
    }

    private void limparFormulario() {
        edNome.setText("");
        edEmail.setText("");
        edIdade.setText("");
        edDisciplina.setText("");
        edNota1.setText("");
        edNota2.setText("");
        tvErro.setVisibility(View.GONE);
        tvResultado.setVisibility(View.GONE);
    }
}